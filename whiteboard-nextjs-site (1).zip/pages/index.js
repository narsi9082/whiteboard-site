import Head from 'next/head'

export default function Home() {
  return (
    <>
      <Head>
        <title>Whiteboard Store - India</title>
      </Head>
      <main className="flex flex-col items-center justify-center min-h-screen p-4 bg-white text-black">
        <h1 className="text-4xl font-bold mb-4">Welcome to India's Favorite Whiteboard Store</h1>
        <p className="text-lg text-center max-w-xl">
          Order premium whiteboards with GPay, PhonePe, or COD. Track your orders and get fast delivery anywhere in India.
        </p>
      </main>
    </>
  )
}
